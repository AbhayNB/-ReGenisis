import adua
import openai
a=adua.Adua()
ans=a.gpt_ans('Give detailed analysis of following e-waste including what are the harmfull component for env and what are pricious metal can be extracted what impact it can cause if not dispose correctly how scrapping metal can contribute to better resource utilization And how he can contribute by recycling this waste (Note if u dont know about that perticular phone u can answer based on category) \n my e-waste: Redmi Note 10, Category: Mobie Phone','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')
print(ans)